#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if [ -x ".venv/bin/nexus" ]; then
  exec .venv/bin/nexus --demo
fi
exec python3 -m nexus --demo
