#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

PY="${PYTHON:-python3}"
"$PY" -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e .

mkdir -p "$HOME/.local/bin"
cat > "$HOME/.local/bin/nexus" <<EOF
#!/usr/bin/env bash
exec "$(pwd)/.venv/bin/nexus" "\$@"
EOF
chmod +x "$HOME/.local/bin/nexus"

echo
echo "NEXUS instalado."
echo "Se ~/.local/bin já estiver no PATH, rode: nexus --demo"
echo "Caso contrário, rode: $(pwd)/.venv/bin/nexus --demo"
