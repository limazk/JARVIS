from dataclasses import dataclass
import os


@dataclass
class Config:
    ollama_model: str = os.getenv("NEXUS_OLLAMA_MODEL", "qwen2.5-coder:14b")
    provider_timeout: int = int(os.getenv("NEXUS_PROVIDER_TIMEOUT", "240"))
    review_enabled: bool = os.getenv("NEXUS_REVIEW", "0").lower() in {"1", "true", "yes", "on"}
    max_output_chars: int = int(os.getenv("NEXUS_MAX_OUTPUT", "24000"))
    history_limit: int = int(os.getenv("NEXUS_HISTORY_LIMIT", "40"))
    db_path: str = os.getenv(
        "NEXUS_DB",
        os.path.expanduser("~/.local/share/nexus/history.db"),
    )
