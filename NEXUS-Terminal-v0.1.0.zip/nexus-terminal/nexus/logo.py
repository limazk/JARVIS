LOGO = [
r"       ✦       ╲        ╱",
r"    ╲  │  ╱     ╲  ✦  ╱",
r"  ───  ★  ───    ╲   ╱",
r"    ╱  │  ╲       ╲ ╱",
r"       ✦         N E X U S",
]

COMPACT_LOGO = [
r"  ✦ NEXUS",
r"  PLANEJA › DELEGA › EXECUTA › ENTREGA",
]
