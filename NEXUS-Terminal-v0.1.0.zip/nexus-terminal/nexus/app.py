from __future__ import annotations

import curses
import locale
import queue
import threading
import time
import textwrap
from collections import deque
from datetime import datetime
from typing import Dict, List, Optional

from .config import Config
from .history import History
from .logo import LOGO, COMPACT_LOGO
from .models import Agent, AgentState, ProviderInfo
from .providers import discover, run_provider
from .router import choose_provider


class NexusApp:
    def __init__(self, stdscr, demo: bool = False):
        self.stdscr = stdscr
        self.demo = demo
        self.config = Config()
        self.providers: Dict[str, ProviderInfo] = discover(self.config)
        self.history = History(self.config.db_path)
        self.logs = deque(maxlen=250)
        self.output_lines = deque(maxlen=250)
        self.message_queue: queue.Queue = queue.Queue()
        self.input_text = ""
        self.cursor = 0
        self.running = True
        self.busy = False
        self.started_at = time.monotonic()
        self.current_job_id: Optional[int] = None
        self.current_prompt = ""
        self.progress = 0.0
        self.result_view = False
        self.status_line = "pronto"
        self.agents = [
            Agent("Planner"),
            Agent("Router"),
            Agent("Researcher"),
            Agent("Coder"),
            Agent("Reviewer"),
            Agent("Tester"),
        ]
        self._init_curses()

    def _init_curses(self):
        locale.setlocale(locale.LC_ALL, "")
        curses.curs_set(1)
        curses.noecho()
        curses.cbreak()
        self.stdscr.keypad(True)
        self.stdscr.timeout(80)
        if curses.has_colors():
            curses.start_color()
            try:
                curses.use_default_colors()
            except Exception:
                pass
            # pair ids: cyan, blue, purple, green, yellow, red, dim
            pairs = [
                (1, curses.COLOR_CYAN, -1),
                (2, curses.COLOR_BLUE, -1),
                (3, curses.COLOR_MAGENTA, -1),
                (4, curses.COLOR_GREEN, -1),
                (5, curses.COLOR_YELLOW, -1),
                (6, curses.COLOR_RED, -1),
                (7, curses.COLOR_WHITE, -1),
            ]
            for pid, fg, bg in pairs:
                try:
                    curses.init_pair(pid, fg, bg)
                except Exception:
                    pass

    def c(self, pair: int, bold: bool = False):
        attr = curses.color_pair(pair) if curses.has_colors() else 0
        if bold:
            attr |= curses.A_BOLD
        return attr

    def safe_add(self, y, x, text, attr=0, maxw=None):
        h, w = self.stdscr.getmaxyx()
        if y < 0 or y >= h or x < 0 or x >= w:
            return
        if maxw is None:
            maxw = w - x - 1
        if maxw <= 0:
            return
        s = str(text).replace("\t", "    ")
        try:
            self.stdscr.addnstr(y, x, s, maxw, attr)
        except curses.error:
            pass

    def box(self, y, x, h, w, title="", pair=2):
        if h < 3 or w < 6:
            return
        attr = self.c(pair)
        self.safe_add(y, x, "╭" + "─" * (w - 2) + "╮", attr, w)
        for yy in range(y + 1, y + h - 1):
            self.safe_add(yy, x, "│", attr, 1)
            self.safe_add(yy, x + w - 1, "│", attr, 1)
        self.safe_add(y + h - 1, x, "╰" + "─" * (w - 2) + "╯", attr, w)
        if title:
            label = f" {title} "
            self.safe_add(y, x + 2, label, self.c(pair, True), w - 4)

    def log(self, actor: str, message: str, pair: int = 7):
        ts = datetime.now().strftime("%H:%M:%S")
        self.logs.append((ts, actor, message, pair))

    def set_agent(self, name: str, state: AgentState, task: str = "", provider: str = "-"):
        for a in self.agents:
            if a.name == name:
                a.state = state
                if task:
                    a.task = task
                if provider:
                    a.provider = provider
                return

    def reset_agents(self):
        for a in self.agents:
            a.state = AgentState.WAITING
            a.task = "aguardando"
            a.provider = "-"

    def process_queue(self):
        while True:
            try:
                kind, payload = self.message_queue.get_nowait()
            except queue.Empty:
                break
            if kind == "log":
                self.log(*payload)
            elif kind == "agent":
                self.set_agent(*payload)
            elif kind == "progress":
                self.progress = float(payload)
            elif kind == "output":
                self.output_lines.append(payload)
            elif kind == "done":
                status, provider, elapsed = payload
                self.busy = False
                self.status_line = status
                if self.current_job_id:
                    self.history.finish(self.current_job_id, status, provider, elapsed)
                self.progress = 1.0 if status == "concluído" else self.progress
                self.set_agent("Reviewer", AgentState.DONE if status == "concluído" else AgentState.ERROR, status, provider)
            elif kind == "reset":
                self.reset_agents()

    def execute_task(self, prompt: str):
        if self.busy:
            self.log("nexus", "já existe uma tarefa em execução", 5)
            return
        self.busy = True
        self.current_prompt = prompt
        self.output_lines.clear()
        self.current_job_id = self.history.start(prompt)
        self.progress = 0.03
        self.status_line = "em andamento"
        t = threading.Thread(target=self._worker, args=(prompt,), daemon=True)
        t.start()

    def _worker(self, prompt: str):
        start = time.monotonic()
        q = self.message_queue
        q.put(("reset", None))
        q.put(("agent", ("Planner", AgentState.PLANNING, "decompor objetivo", "-")))
        q.put(("log", ("nexus", f'Iniciando tarefa: "{prompt[:100]}"', 3)))
        time.sleep(0.25)
        q.put(("progress", 0.12))
        q.put(("log", ("planner", "Analisando objetivo e restrições...", 1)))
        time.sleep(0.25)

        provider, kind = choose_provider(prompt, self.providers)
        q.put(("agent", ("Router", AgentState.ROUTING, f"classe: {kind}", provider or "-")))
        q.put(("log", ("router", f"Tipo detectado: {kind}", 3)))
        time.sleep(0.2)

        if self.demo:
            provider = provider or "codex"
            q.put(("log", ("router", f"[DEMO] Delegando para {provider}", 3)))
            q.put(("progress", 0.32))
            agent = "Coder" if kind == "code" else ("Researcher" if kind == "research" else "Coder")
            state = AgentState.CODING if agent == "Coder" else AgentState.RESEARCHING
            q.put(("agent", (agent, state, "executando subtarefa", provider)))
            demo_lines = [
                "Preparando contexto mínimo...",
                "Analisando arquivos e dependências...",
                "Executando tarefa principal...",
                "Validando resultado...",
                "Resultado de demonstração concluído com sucesso.",
            ]
            for i, line in enumerate(demo_lines):
                time.sleep(0.35)
                q.put(("output", line))
                q.put(("log", (agent.lower(), line, 1)))
                q.put(("progress", 0.35 + i * 0.11))
            q.put(("agent", ("Reviewer", AgentState.REVIEWING, "validação final", provider)))
            time.sleep(0.35)
            q.put(("output", "NEXUS DEMO: pipeline funcional; nenhum provider externo foi chamado."))
            elapsed = time.monotonic() - start
            q.put(("done", ("concluído", provider, elapsed)))
            return

        if not provider:
            elapsed = time.monotonic() - start
            q.put(("log", ("router", "Nenhum provider de IA disponível. Use /providers.", 6)))
            q.put(("output", "Nenhum CLI compatível foi encontrado. Instale/autentique Claude, Codex, Gemini ou Ollama."))
            q.put(("done", ("erro", "-", elapsed)))
            return

        q.put(("log", ("router", f"Delegando para {provider}", 3)))
        q.put(("progress", 0.28))
        target_agent = "Coder" if kind in {"code", "general"} else ("Researcher" if kind == "research" else "Reviewer")
        target_state = {
            "Coder": AgentState.CODING,
            "Researcher": AgentState.RESEARCHING,
            "Reviewer": AgentState.REVIEWING,
        }[target_agent]
        q.put(("agent", (target_agent, target_state, "executando tarefa", provider)))

        def on_line(line: str):
            if line.strip():
                q.put(("output", line))
                q.put(("progress", min(0.88, 0.38 + len(self.output_lines) * 0.01)))

        code, output = run_provider(provider, prompt, self.config, on_line=on_line)
        if output and not self.output_lines:
            for line in output.splitlines():
                q.put(("output", line))

        q.put(("agent", ("Reviewer", AgentState.REVIEWING, "checagem final", provider)))
        q.put(("progress", 0.92))
        time.sleep(0.15)

        elapsed = time.monotonic() - start
        if code == 0:
            q.put(("log", ("reviewer", "Execução concluída", 4)))
            q.put(("done", ("concluído", provider, elapsed)))
        else:
            q.put(("log", ("nexus", f"Falha do provider: {output[-400:]}", 6)))
            q.put(("done", ("erro", provider, elapsed)))

    def command(self, text: str):
        cmd = text.strip()
        if not cmd:
            return
        if cmd == "/quit":
            self.running = False
        elif cmd == "/clear":
            self.logs.clear()
            self.output_lines.clear()
            self.status_line = "pronto"
        elif cmd == "/providers":
            for p in self.providers.values():
                st = "disponível" if p.available else "offline"
                self.log("provider", f"{p.label:<12} {st:<11} {p.model}", 4 if p.available else 6)
        elif cmd == "/refresh":
            self.providers = discover(self.config)
            self.log("nexus", "providers reescaneados", 4)
        elif cmd == "/demo":
            self.demo = not self.demo
            self.log("nexus", f"modo demo: {'ON' if self.demo else 'OFF'}", 5)
        elif cmd == "/result":
            self.result_view = not self.result_view
        elif cmd == "/help":
            self.log("nexus", "/providers  /refresh  /demo  /result  /clear  /quit", 1)
        else:
            self.execute_task(cmd)

    def handle_key(self, ch):
        if ch == -1:
            return
        if ch in (3,):  # Ctrl-C
            if self.busy:
                self.log("nexus", "Ctrl-C recebido; a UI permanece ativa. O provider pode finalizar pelo timeout.", 5)
            else:
                self.running = False
            return
        if ch == 27:  # Esc
            self.input_text = ""
            self.cursor = 0
            return
        if ch in (10, 13):
            text = self.input_text.strip()
            self.input_text = ""
            self.cursor = 0
            if text:
                self.command(text)
            return
        if ch in (curses.KEY_BACKSPACE, 127, 8):
            if self.cursor > 0:
                self.input_text = self.input_text[: self.cursor - 1] + self.input_text[self.cursor :]
                self.cursor -= 1
            return
        if ch == curses.KEY_LEFT:
            self.cursor = max(0, self.cursor - 1)
            return
        if ch == curses.KEY_RIGHT:
            self.cursor = min(len(self.input_text), self.cursor + 1)
            return
        if ch == curses.KEY_HOME:
            self.cursor = 0
            return
        if ch == curses.KEY_END:
            self.cursor = len(self.input_text)
            return
        if 32 <= ch <= 0x10FFFF:
            try:
                c = chr(ch)
            except ValueError:
                return
            self.input_text = self.input_text[: self.cursor] + c + self.input_text[self.cursor :]
            self.cursor += 1

    def draw_header(self, h, w):
        header_h = 7 if h >= 32 else 4
        logo = LOGO if header_h >= 7 and w >= 100 else COMPACT_LOGO
        for i, line in enumerate(logo[: header_h - 1]):
            self.safe_add(i, 2, line, self.c(3 if i % 2 else 1, True), min(len(line)+2, w//2))
        if w >= 90:
            rx = max(w // 2 + 8, 55)
            self.safe_add(1, rx, "Orquestrador multiagente para", self.c(7))
            self.safe_add(2, rx, "transformar ideias em resultados.", self.c(7))
            if header_h >= 7:
                self.safe_add(4, rx, "PLANEJA  ›  DELEGA  ›  EXECUTA  ›  ENTREGA", self.c(1, True))
        return header_h

    def draw_system(self, y, x, h, w):
        self.box(y, x, h, w, "SISTEMA", 2)
        self.safe_add(y + 1, x + 2, "PROVIDER       STATUS        MODELO / VERSÃO", self.c(7, True), w - 4)
        rows = [p for k, p in self.providers.items() if k in {"claude", "codex", "gemini", "ollama"}]
        for i, p in enumerate(rows[: max(0, h - 3)]):
            yy = y + 2 + i
            dot = "●"
            status = "disponível" if p.available else "offline"
            pair = 4 if p.available else 6
            self.safe_add(yy, x + 2, dot, self.c(pair, True), 2)
            self.safe_add(yy, x + 4, f"{p.label:<13}", self.c(7, True), 14)
            self.safe_add(yy, x + 18, f"{status:<13}", self.c(pair), 13)
            self.safe_add(yy, x + 31, p.model, self.c(7), w - 33)

    def draw_agents(self, y, x, h, w):
        self.box(y, x, h, w, "AGENTES ATIVOS", 3)
        self.safe_add(y + 1, x + 2, "AGENTE         STATUS         TAREFA", self.c(7, True), w - 4)
        state_pair = {
            AgentState.WAITING: 7,
            AgentState.PLANNING: 3,
            AgentState.ROUTING: 3,
            AgentState.RESEARCHING: 1,
            AgentState.CODING: 3,
            AgentState.REVIEWING: 5,
            AgentState.RUNNING: 1,
            AgentState.DONE: 4,
            AgentState.ERROR: 6,
        }
        for i, a in enumerate(self.agents[: max(0, h - 3)]):
            yy = y + 2 + i
            pair = state_pair.get(a.state, 7)
            self.safe_add(yy, x + 2, f"● {a.name:<12}", self.c(pair, True), 15)
            self.safe_add(yy, x + 17, f"{a.state.value:<14}", self.c(pair), 14)
            self.safe_add(yy, x + 31, a.task, self.c(7), w - 33)

    def draw_execution(self, y, x, h, w):
        self.box(y, x, h, w, "EXECUÇÃO", 2)
        elapsed = time.monotonic() - self.started_at
        self.safe_add(y + 1, x + w - 12, f"{elapsed/60:05.1f}m", self.c(7), 9)
        task = self.current_prompt or "Aguardando nova tarefa"
        self.safe_add(y + 2, x + 2, "Tarefa atual │ ", self.c(7), 15)
        self.safe_add(y + 2, x + 16, task, self.c(1, True), w - 18)

        steps = [
            ("Planejar arquitetura e subtarefas", 0.10),
            ("Delegar tarefa ao melhor provider", 0.25),
            ("Executar trabalho principal", 0.45),
            ("Validar resultado", 0.90),
            ("Entregar resultado", 1.00),
        ]
        max_steps = min(len(steps), max(0, h - 7))
        for i, (label, threshold) in enumerate(steps[:max_steps]):
            yy = y + 3 + i
            done = self.progress >= threshold
            icon = "✓" if done else "○"
            pair = 4 if done else 7
            self.safe_add(yy, x + 2, f"{icon} {label}", self.c(pair), w - 4)

        bar_y = y + h - 3
        inner = max(8, w - 13)
        filled = int(inner * max(0, min(1, self.progress)))
        bar = "█" * filled + "░" * (inner - filled)
        self.safe_add(bar_y, x + 2, bar, self.c(3), inner)
        self.safe_add(bar_y, x + 3 + inner, f"{int(self.progress*100):>3}%", self.c(7), 5)
        self.safe_add(y + h - 2, x + 2, f"Status: {self.status_line}", self.c(4 if self.status_line=="concluído" else 7), w - 4)

    def draw_logs(self, y, x, h, w):
        title = "RESULTADO" if self.result_view else "LOGS"
        self.box(y, x, h, w, title, 2)
        if self.result_view:
            lines = list(self.output_lines)
            display = lines[-max(0, h - 2):]
            for i, line in enumerate(display):
                self.safe_add(y + 1 + i, x + 2, line, self.c(7), w - 4)
        else:
            logs = list(self.logs)[-max(0, h - 2):]
            for i, (ts, actor, msg, pair) in enumerate(logs):
                yy = y + 1 + i
                prefix = f"[{ts}] {actor:<10} › "
                self.safe_add(yy, x + 2, prefix, self.c(pair, True), min(len(prefix), w - 4))
                self.safe_add(yy, x + 2 + len(prefix), msg, self.c(7), max(0, w - 4 - len(prefix)))

    def draw_history(self, y, x, h, w):
        self.box(y, x, h, w, "TRABALHOS RECENTES", 3)
        self.safe_add(y + 1, x + 2, "#    TAREFA                         STATUS", self.c(7, True), w - 4)
        rows = self.history.recent(max(1, h - 3))
        for i, row in enumerate(rows[: max(0, h - 3)]):
            job_id, prompt, status, provider, elapsed = row
            yy = y + 2 + i
            p = prompt.replace("\n", " ")
            pair = 4 if status == "concluído" else (6 if status == "erro" else 1)
            self.safe_add(yy, x + 2, f"{job_id:<4} {p[:28]:<28}", self.c(7), min(34, w - 4))
            if w > 48:
                self.safe_add(yy, x + 36, status, self.c(pair, True), w - 38)

    def draw_input(self, h, w):
        y = h - 3
        if y < 1:
            return
        self.safe_add(y, 1, "NEXUS ❯", self.c(3, True), 8)
        x = 10
        width = max(5, w - x - 2)
        self.safe_add(y, x, " " * width, curses.A_REVERSE, width)
        visible = self.input_text[-(width - 2):] if len(self.input_text) >= width - 1 else self.input_text
        self.safe_add(y, x + 1, visible or "descreva sua tarefa...  (/help)", curses.A_DIM, width - 2)
        self.safe_add(h - 2, 1, "Enter enviar   / comandos   ? ajuda   Esc limpar   Ctrl+C sair", self.c(7), w - 3)
        online = sum(1 for p in self.providers.values() if p.key in {"claude","codex","gemini","ollama"} and p.available)
        self.safe_add(h - 2, max(1, w - 28), f"● {online} providers  │  v0.1.0", self.c(4), 27)
        try:
            # approximate cursor position in visible buffer
            curx = x + 1 + min(len(visible), width - 2)
            self.stdscr.move(y, curx)
        except curses.error:
            pass

    def draw(self):
        self.stdscr.erase()
        h, w = self.stdscr.getmaxyx()
        if h < 18 or w < 70:
            self.safe_add(1, 2, "NEXUS", self.c(3, True))
            self.safe_add(3, 2, "Terminal pequeno demais.", self.c(6, True))
            self.safe_add(4, 2, "Use pelo menos 70x18. Recomendado: 120x32.", self.c(7))
            self.draw_input(h, w)
            self.stdscr.refresh()
            return

        header_h = self.draw_header(h, w)
        content_top = header_h
        content_bottom = h - 4
        content_h = max(10, content_bottom - content_top)

        if w >= 120 and content_h >= 18:
            top_h = min(10, max(8, content_h // 3))
            bottom_y = content_top + top_h
            bottom_h = content_bottom - bottom_y

            left_w = int(w * 0.34)
            mid_w = int(w * 0.31)
            right_w = w - left_w - mid_w - 1

            self.draw_system(content_top, 0, top_h, left_w)
            self.draw_agents(content_top, left_w, top_h, mid_w)
            self.draw_execution(content_top, left_w + mid_w, top_h, right_w)

            logs_w = int(w * 0.64)
            hist_w = w - logs_w
            self.draw_logs(bottom_y, 0, bottom_h, logs_w)
            self.draw_history(bottom_y, logs_w, bottom_h, hist_w)
        else:
            top_h = min(9, max(7, content_h // 3))
            half = w // 2
            self.draw_agents(content_top, 0, top_h, half)
            self.draw_execution(content_top, half, top_h, w - half)
            self.draw_logs(content_top + top_h, 0, content_h - top_h, w)

        self.draw_input(h, w)
        self.stdscr.refresh()

    def run(self):
        self.log("nexus", "NEXUS iniciado. Digite /help para comandos.", 3)
        if self.demo:
            self.log("nexus", "Modo DEMO ativo: providers externos não serão chamados.", 5)
        while self.running:
            self.process_queue()
            self.draw()
            try:
                ch = self.stdscr.get_wch()
                if isinstance(ch, str):
                    if ch == "\n":
                        code = 10
                    elif ch == "\x1b":
                        code = 27
                    elif ch == "\x03":
                        code = 3
                    elif ch in ("\x7f", "\b"):
                        code = 127
                    else:
                        code = ord(ch)
                else:
                    code = ch
                self.handle_key(code)
            except curses.error:
                pass
            except KeyboardInterrupt:
                self.handle_key(3)


def launch(demo: bool = False):
    curses.wrapper(lambda stdscr: NexusApp(stdscr, demo=demo).run())
