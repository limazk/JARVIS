from __future__ import annotations
import os
import sqlite3
from typing import List, Tuple


class History:
    def __init__(self, db_path: str):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS jobs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prompt TEXT NOT NULL,
                status TEXT NOT NULL,
                provider TEXT,
                elapsed REAL DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        self.conn.commit()

    def start(self, prompt: str) -> int:
        cur = self.conn.execute(
            "INSERT INTO jobs(prompt,status) VALUES(?,?)",
            (prompt, "em andamento"),
        )
        self.conn.commit()
        return int(cur.lastrowid)

    def finish(self, job_id: int, status: str, provider: str, elapsed: float):
        self.conn.execute(
            "UPDATE jobs SET status=?,provider=?,elapsed=? WHERE id=?",
            (status, provider, elapsed, job_id),
        )
        self.conn.commit()

    def recent(self, limit: int = 8) -> List[Tuple]:
        cur = self.conn.execute(
            """
            SELECT id,prompt,status,provider,elapsed
            FROM jobs
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        )
        return cur.fetchall()
