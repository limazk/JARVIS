from __future__ import annotations
from typing import Dict, Tuple
from .models import ProviderInfo


CODE_WORDS = {
    "código", "codigo", "bug", "python", "javascript", "typescript", "react",
    "api", "backend", "frontend", "git", "docker", "refator", "teste", "função",
    "funcao", "classe", "repo", "repositório", "repositorio", "implementar",
}
RESEARCH_WORDS = {
    "pesquise", "pesquisar", "pesquisa", "documentação", "documentacao",
    "referências", "referencias", "compare", "mercado", "notícias", "noticias",
}
REVIEW_WORDS = {
    "revise", "revisar", "review", "audite", "auditar", "analise código",
    "analise o código", "segurança", "seguranca",
}


def classify(prompt: str) -> str:
    p = prompt.lower()
    if any(w in p for w in REVIEW_WORDS):
        return "review"
    if any(w in p for w in CODE_WORDS):
        return "code"
    if any(w in p for w in RESEARCH_WORDS):
        return "research"
    return "general"


def choose_provider(prompt: str, providers: Dict[str, ProviderInfo]) -> Tuple[str, str]:
    kind = classify(prompt)
    priorities = {
        "code": ["codex", "claude", "gemini", "ollama"],
        "review": ["claude", "codex", "gemini", "ollama"],
        "research": ["gemini", "claude", "codex", "ollama"],
        "general": ["claude", "gemini", "ollama", "codex"],
    }
    for key in priorities[kind]:
        if providers.get(key) and providers[key].available:
            return key, kind
    return "", kind
