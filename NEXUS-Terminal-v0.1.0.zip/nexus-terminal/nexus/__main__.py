from __future__ import annotations

import argparse
import json
import os
import sys

from . import __version__
from .config import Config
from .providers import discover


def doctor():
    config = Config()
    providers = discover(config)
    print(f"NEXUS v{__version__}")
    print("Diagnóstico de providers")
    print("-" * 56)
    for p in providers.values():
        status = "OK" if p.available else "OFFLINE"
        print(f"{p.label:<14} {status:<8} {p.executable:<10} {p.model}")
    print("-" * 56)
    print(f"DB: {config.db_path}")
    print(f"Review extra: {'ON' if config.review_enabled else 'OFF'}")
    print("Terminal recomendado: 120x32 ou maior")


def main():
    parser = argparse.ArgumentParser(
        prog="nexus",
        description="NEXUS - terminal multi-agent orchestrator",
    )
    parser.add_argument("--demo", action="store_true", help="abre a TUI sem chamar providers externos")
    parser.add_argument("--doctor", action="store_true", help="diagnostica CLIs/providers")
    parser.add_argument("--version", action="store_true", help="mostra a versão")
    args = parser.parse_args()

    if args.version:
        print(__version__)
        return
    if args.doctor:
        doctor()
        return

    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print("NEXUS precisa de um terminal interativo. Use: nexus --doctor")
        raise SystemExit(2)

    from .app import launch
    launch(demo=args.demo)


if __name__ == "__main__":
    main()
