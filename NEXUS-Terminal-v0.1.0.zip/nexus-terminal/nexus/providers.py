from __future__ import annotations

import shutil
import subprocess
from dataclasses import replace
from typing import Callable, Dict, List, Tuple

from .config import Config
from .models import ProviderInfo


def _base_providers(config: Config) -> Dict[str, ProviderInfo]:
    return {
        "claude": ProviderInfo("claude", "Claude", "claude", "Claude CLI"),
        "codex": ProviderInfo("codex", "Codex", "codex", "Codex CLI"),
        "gemini": ProviderInfo("gemini", "Gemini", "gemini", "Gemini CLI"),
        "ollama": ProviderInfo("ollama", "Qwen Local", "ollama", config.ollama_model),
        "git": ProviderInfo("git", "Git", "git", "sistema"),
        "docker": ProviderInfo("docker", "Docker", "docker", "sistema"),
    }


def discover(config: Config) -> Dict[str, ProviderInfo]:
    out = {}
    for key, p in _base_providers(config).items():
        out[key] = replace(p, available=shutil.which(p.executable) is not None)
    return out


def _commands(provider: str, prompt: str, config: Config) -> List[List[str]]:
    # A small fallback chain is intentional because CLI flags vary by version.
    if provider == "claude":
        return [
            ["claude", "-p", prompt],
            ["claude", "--print", prompt],
        ]
    if provider == "codex":
        return [
            ["codex", "exec", prompt],
            ["codex", "exec", "--skip-git-repo-check", prompt],
        ]
    if provider == "gemini":
        return [
            ["gemini", "-p", prompt],
            ["gemini", "--prompt", prompt],
        ]
    if provider == "ollama":
        return [
            ["ollama", "run", config.ollama_model, prompt],
        ]
    raise ValueError(f"Provider não suportado: {provider}")


def run_provider(
    provider: str,
    prompt: str,
    config: Config,
    on_line: Callable[[str], None] | None = None,
) -> Tuple[int, str]:
    """Run one provider CLI, streaming lines when possible."""
    last_error = ""
    for command in _commands(provider, prompt, config):
        try:
            proc = subprocess.Popen(
                command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True,
            )
        except FileNotFoundError:
            return 127, f"{provider}: executável não encontrado."
        except Exception as exc:
            last_error = str(exc)
            continue

        chunks: List[str] = []
        started = __import__("time").monotonic()
        try:
            assert proc.stdout is not None
            while True:
                if __import__("time").monotonic() - started > config.provider_timeout:
                    proc.kill()
                    return 124, f"{provider}: timeout após {config.provider_timeout}s"

                line = proc.stdout.readline()
                if line:
                    line = line.rstrip("\n")
                    chunks.append(line)
                    if on_line:
                        on_line(line)
                    if sum(map(len, chunks)) > config.max_output_chars:
                        chunks.append("\n[saída truncada pelo NEXUS]")
                        proc.kill()
                        return 0, "\n".join(chunks)
                elif proc.poll() is not None:
                    break

            code = proc.wait()
            output = "\n".join(chunks).strip()
            if code == 0:
                return 0, output
            last_error = output or f"comando saiu com código {code}"
        except Exception as exc:
            try:
                proc.kill()
            except Exception:
                pass
            last_error = str(exc)

    return 1, last_error or f"{provider}: falha desconhecida."
