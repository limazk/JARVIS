from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class AgentState(str, Enum):
    WAITING = "aguardando"
    PLANNING = "planejando"
    ROUTING = "roteando"
    RESEARCHING = "pesquisando"
    CODING = "editando"
    REVIEWING = "revisando"
    RUNNING = "executando"
    DONE = "concluído"
    ERROR = "erro"


@dataclass
class ProviderInfo:
    key: str
    label: str
    executable: str
    model: str
    available: bool = False


@dataclass
class Agent:
    name: str
    state: AgentState = AgentState.WAITING
    task: str = "aguardando"
    provider: str = "-"


@dataclass
class Job:
    id: int
    prompt: str
    status: str = "em andamento"
    provider: str = "-"
    created_at: datetime = field(default_factory=datetime.now)
    elapsed: float = 0.0
    result: str = ""
    error: Optional[str] = None
