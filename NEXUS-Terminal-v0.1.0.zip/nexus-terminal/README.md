# NEXUS Terminal

TUI funcional do **NEXUS**, desenhada para rodar diretamente no terminal Linux.

## O que já funciona

- Interface em terminal com painéis, cores, bordas, logs e progresso.
- Detecção automática de `claude`, `codex`, `gemini` e `ollama`.
- Router simples que decide qual provider usar conforme a tarefa.
- Execução em thread para manter a interface responsiva.
- Histórico persistente em SQLite.
- Modo `--demo`, que mostra o fluxo completo sem gastar API/tokens.
- Comandos internos: `/help`, `/providers`, `/refresh`, `/demo`, `/result`, `/clear`, `/quit`.
- Layout responsivo: completo em terminais largos e compacto em terminais menores.
- Zero dependências Python externas: usa apenas a biblioteca padrão.

## Instalação rápida

```bash
chmod +x install.sh
./install.sh
nexus --demo
```

Se `~/.local/bin` não estiver no PATH:

```bash
./.venv/bin/nexus --demo
```

## Diagnóstico

```bash
nexus --doctor
```

## Uso real

Depois de autenticar pelo menos um CLI compatível:

```bash
nexus
```

O NEXUS tenta escolher automaticamente:

- código → Codex → Claude → Gemini → Ollama
- revisão → Claude → Codex → Gemini → Ollama
- pesquisa → Gemini → Claude → Codex → Ollama
- geral → Claude → Gemini → Ollama → Codex

As integrações usam os CLIs já instalados no sistema. O NEXUS **não armazena suas chaves**.

## Modo demo

```bash
nexus --demo
```

Digite algo como:

```text
Crie uma API Python com autenticação e testes
```

A UI mostrará Planner, Router, Coder/Researcher e Reviewer mudando de estado em tempo real.

## Configuração por variáveis de ambiente

```bash
export NEXUS_OLLAMA_MODEL="qwen2.5-coder:14b"
export NEXUS_PROVIDER_TIMEOUT=240
export NEXUS_MAX_OUTPUT=24000
export NEXUS_REVIEW=0
```

## Observação

Esta entrega é um MVP funcional do terminal/orquestrador. Providers externos só funcionam quando seus respectivos CLIs estão instalados e autenticados no computador.
