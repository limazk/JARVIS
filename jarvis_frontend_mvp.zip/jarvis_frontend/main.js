const state = {
  provider: "auto",
  activityCount: 1,
  backendOnline: false,
  voiceEnabled: true,
  demoMode: true
};

const el = {
  clock: document.getElementById("clock"),
  date: document.getElementById("date"),
  orb: document.getElementById("jarvisOrb"),
  agentState: document.getElementById("agentState"),
  agentMessage: document.getElementById("agentMessage"),
  agentSubtext: document.getElementById("agentSubtext"),
  input: document.getElementById("messageInput"),
  send: document.getElementById("sendButton"),
  mic: document.getElementById("micButton"),
  chat: document.getElementById("chatList"),
  clearChat: document.getElementById("clearChat"),
  activityList: document.getElementById("activityList"),
  activityCount: document.getElementById("activityCount"),
  traceProvider: document.getElementById("traceProvider"),
  traceIntent: document.getElementById("traceIntent"),
  traceTool: document.getElementById("traceTool"),
  traceRisk: document.getElementById("traceRisk"),
  footerProvider: document.getElementById("footerProvider"),
  backendStatus: document.getElementById("backendStatus")
};

function updateClock() {
  const now = new Date();

  el.clock.textContent = now.toLocaleTimeString("pt-BR");
  el.date.textContent = now.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  });
}

updateClock();
setInterval(updateClock, 1000);

function setAgentState(type, title, subtitle = "") {
  el.orb.className = "orb";

  if (type !== "online") {
    el.orb.classList.add(type);
  }

  const states = {
    online: "ONLINE",
    listening: "LISTENING",
    processing: "PROCESSING",
    speaking: "SPEAKING",
    executing: "EXECUTING",
    error: "ERROR"
  };

  el.agentState.textContent = states[type] || "ONLINE";
  el.agentMessage.textContent = title;
  el.agentSubtext.textContent = subtitle;

  if (type === "error") {
    el.agentState.style.color = "var(--danger)";
  } else if (type === "processing") {
    el.agentState.style.color = "var(--purple-soft)";
  } else {
    el.agentState.style.color = "var(--green)";
  }
}

function addMessage(sender, text) {
  const article = document.createElement("article");
  const isUser = sender === "VOCÊ";

  article.className = `message ${isUser ? "user-message" : "jarvis-message"}`;

  const now = new Date().toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit"
  });

  article.innerHTML = `
    <div class="message-meta">
      <span>${sender}</span>
      <time>${now}</time>
    </div>
    <div class="message-bubble"></div>
  `;

  article.querySelector(".message-bubble").textContent = text;
  el.chat.appendChild(article);
  el.chat.scrollTop = el.chat.scrollHeight;
}

function addActivity(title, subtitle = "Comando processado") {
  state.activityCount += 1;

  const now = new Date().toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit"
  });

  const item = document.createElement("div");
  item.className = "activity-item";
  item.innerHTML = `
    <span class="activity-time">${now}</span>
    <div>
      <strong></strong>
      <small></small>
    </div>
  `;

  item.querySelector("strong").textContent = title;
  item.querySelector("small").textContent = subtitle;

  el.activityList.prepend(item);
  el.activityCount.textContent = `${state.activityCount} EVENTOS`;
}

function updateTrace({ provider, intent, tool, risk }) {
  el.traceProvider.textContent = (provider || state.provider).toUpperCase();
  el.traceIntent.textContent = intent || "IDLE";
  el.traceTool.textContent = tool || "NONE";
  el.traceRisk.textContent = risk || "LOW";
}

function speak(text) {
  if (!state.voiceEnabled || !("speechSynthesis" in window)) {
    setAgentState("online", "Como posso ajudar?", "Aguardando comando de voz ou texto.");
    return;
  }

  speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "pt-BR";
  utterance.rate = 1.02;
  utterance.pitch = 0.92;

  utterance.onstart = () => {
    setAgentState("speaking", "Respondendo...", "Saída de voz ativa.");
  };

  utterance.onend = () => {
    setAgentState("online", "Como posso ajudar?", "Aguardando comando de voz ou texto.");
  };

  speechSynthesis.speak(utterance);
}

function detectIntent(text) {
  const value = text.toLowerCase();

  if (value.includes("spotify")) {
    return { intent: "OPEN_APP", tool: "BROWSER", risk: "LOW" };
  }

  if (value.includes("youtube")) {
    return { intent: "OPEN_URL", tool: "BROWSER", risk: "LOW" };
  }

  if (
    value.includes("que horas") ||
    value.includes("horário") ||
    value.includes("horas")
  ) {
    return { intent: "GET_TIME", tool: "LOCAL", risk: "LOW" };
  }

  if (value.includes("ram")) {
    return { intent: "GET_RAM", tool: "SYSTEM", risk: "LOW" };
  }

  if (value.includes("cpu")) {
    return { intent: "GET_CPU", tool: "SYSTEM", risk: "LOW" };
  }

  if (value.includes("pesquise") || value.includes("pesquisa")) {
    return { intent: "WEB_SEARCH", tool: "BROWSER", risk: "LOW" };
  }

  return { intent: "CHAT", tool: "AI", risk: "LOW" };
}

function localDemoResponse(message) {
  const normalized = message.toLowerCase().replace("jarvis", "").trim();
  const meta = detectIntent(normalized);

  if (meta.intent === "GET_TIME") {
    return {
      text: `Agora são ${new Date().toLocaleTimeString("pt-BR", {
        hour: "2-digit",
        minute: "2-digit"
      })}.`,
      activity: "Horário consultado",
      meta
    };
  }

  if (meta.intent === "GET_RAM") {
    return {
      text: `O uso de RAM exibido no modo demonstração é ${document.getElementById("ramValue").textContent}.`,
      activity: "Memória RAM consultada",
      meta
    };
  }

  if (meta.intent === "GET_CPU") {
    return {
      text: `O uso de CPU exibido no modo demonstração é ${document.getElementById("cpuValue").textContent}.`,
      activity: "CPU consultada",
      meta
    };
  }

  if (normalized.includes("spotify")) {
    window.open("https://open.spotify.com", "_blank");
    return {
      text: "Abrindo o Spotify no navegador.",
      activity: "Spotify aberto",
      meta
    };
  }

  if (normalized.includes("youtube")) {
    window.open("https://youtube.com", "_blank");
    return {
      text: "Abrindo o YouTube.",
      activity: "YouTube aberto",
      meta
    };
  }

  if (meta.intent === "WEB_SEARCH") {
    const query = normalized
      .replace("pesquise", "")
      .replace("pesquisa", "")
      .trim();

    if (query) {
      window.open(
        `https://www.google.com/search?q=${encodeURIComponent(query)}`,
        "_blank"
      );

      return {
        text: `Pesquisando por ${query}.`,
        activity: `Pesquisa: ${query}`,
        meta
      };
    }
  }

  return {
    text:
      state.provider === "local"
        ? "Esse comando precisa de um modelo de IA conectado ao backend."
        : `Modo de demonstração ativo. Quando o backend estiver conectado, essa mensagem será enviada para ${
            state.provider === "auto" ? "o roteador automático de IA" : state.provider
          }.`,
    activity: "Mensagem processada em modo demo",
    meta
  };
}

async function sendToBackend(message) {
  const response = await fetch("http://127.0.0.1:8000/chat", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      message,
      provider: state.provider
    })
  });

  if (!response.ok) {
    throw new Error(`Backend respondeu com HTTP ${response.status}`);
  }

  return await response.json();
}

async function processMessage(message) {
  addMessage("VOCÊ", message);
  el.input.value = "";

  const meta = detectIntent(message);
  updateTrace({
    provider: state.provider,
    intent: meta.intent,
    tool: meta.tool,
    risk: meta.risk
  });

  setAgentState(
    "processing",
    "Analisando comando...",
    `Intent: ${meta.intent} • Tool: ${meta.tool}`
  );

  let result;

  try {
    if (state.backendOnline) {
      const backendData = await sendToBackend(message);

      result = {
        text: backendData.response || "Resposta recebida sem conteúdo.",
        activity: backendData.activity || "Backend processou o comando",
        meta: {
          intent: backendData.intent || meta.intent,
          tool: backendData.tool || meta.tool,
          risk: backendData.risk || meta.risk
        }
      };
    } else {
      await delay(480);
      result = localDemoResponse(message);
    }

    updateTrace({
      provider: state.provider,
      intent: result.meta.intent,
      tool: result.meta.tool,
      risk: result.meta.risk
    });

    addMessage("JARVIS", result.text);
    addActivity(result.activity, `${result.meta.intent} • ${result.meta.tool}`);
    speak(result.text);
  } catch (error) {
    console.error(error);

    setAgentState(
      "error",
      "Não consegui completar a ação.",
      "Verifique a conexão com o backend."
    );

    addMessage(
      "JARVIS",
      "Não consegui me conectar ao backend. O modo demonstração continua disponível."
    );

    addActivity("Falha no backend", error.message);
  }
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function handleSend() {
  const value = el.input.value.trim();

  if (!value) return;

  processMessage(value);
}

el.send.addEventListener("click", handleSend);

el.input.addEventListener("keydown", event => {
  if (event.key === "Enter") {
    handleSend();
  }
});

document.querySelectorAll(".quick-actions button").forEach(button => {
  button.addEventListener("click", () => {
    el.input.value = button.dataset.command;
    handleSend();
  });
});

document.querySelectorAll(".core-btn").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".core-btn").forEach(btn => {
      btn.classList.remove("active");
    });

    button.classList.add("active");

    state.provider = button.dataset.provider;

    el.traceProvider.textContent = state.provider.toUpperCase();
    el.footerProvider.textContent = `AI CORE: ${state.provider.toUpperCase()}`;

    addActivity(
      `AI Core alterado para ${state.provider.toUpperCase()}`,
      "Provider selecionado manualmente"
    );
  });
});

el.clearChat.addEventListener("click", () => {
  el.chat.innerHTML = "";
  addMessage("JARVIS", "Histórico visual limpo. Estou pronto.");
});

const SpeechRecognition =
  window.SpeechRecognition ||
  window.webkitSpeechRecognition;

if (SpeechRecognition) {
  const recognition = new SpeechRecognition();

  recognition.lang = "pt-BR";
  recognition.continuous = false;
  recognition.interimResults = false;

  el.mic.addEventListener("click", () => {
    try {
      recognition.start();
      el.mic.classList.add("active");

      setAgentState(
        "listening",
        "Estou ouvindo...",
        "Fale seu comando."
      );
    } catch (error) {
      console.warn(error);
    }
  });

  recognition.onresult = event => {
    const transcript = event.results[0][0].transcript;

    el.input.value = transcript;
    el.mic.classList.remove("active");

    processMessage(transcript);
  };

  recognition.onerror = event => {
    console.warn("Erro de reconhecimento de voz:", event.error);

    el.mic.classList.remove("active");

    setAgentState(
      "online",
      "Como posso ajudar?",
      "Não consegui captar a voz. Você pode digitar o comando."
    );
  };

  recognition.onend = () => {
    el.mic.classList.remove("active");
  };
} else {
  document.getElementById("microphoneStatus").textContent = "UNAVAILABLE";
  document.getElementById("microphoneStatus").className = "connection-off";

  el.mic.addEventListener("click", () => {
    addMessage(
      "JARVIS",
      "Seu navegador não disponibilizou reconhecimento de voz para esta página."
    );
  });
}

function updateDemoMetrics() {
  if (state.backendOnline) return;

  const ranges = {
    cpu: [9, 38],
    ram: [38, 55],
    gpu: [4, 34],
    disk: [61, 61]
  };

  Object.entries(ranges).forEach(([name, range]) => {
    const [min, max] = range;
    const value =
      min === max
        ? min
        : Math.floor(Math.random() * (max - min + 1)) + min;

    document.getElementById(`${name}Value`).textContent = `${value}%`;
    document.getElementById(`${name}Bar`).style.width = `${value}%`;
  });
}

setInterval(updateDemoMetrics, 3500);

async function checkBackend() {
  try {
    const response = await fetch("http://127.0.0.1:8000/health", {
      method: "GET"
    });

    if (!response.ok) throw new Error();

    const data = await response.json();

    state.backendOnline = true;
    state.demoMode = false;

    el.backendStatus.textContent = "ONLINE";
    el.backendStatus.className = "connection-on";

    if (data.openai === true) {
      document.getElementById("openaiStatus").textContent = "ONLINE";
      document.getElementById("openaiStatus").className = "connection-on";
    }

    if (data.claude === true) {
      document.getElementById("claudeStatus").textContent = "ONLINE";
      document.getElementById("claudeStatus").className = "connection-on";
    }
  } catch {
    state.backendOnline = false;
    el.backendStatus.textContent = "DEMO";
    el.backendStatus.className = "connection-off";
  }
}

checkBackend();
setInterval(checkBackend, 10000);
