# JARVIS Frontend MVP

Interface web do protótipo JARVIS.

## Arquivos

- `index.html` — estrutura da interface
- `style.css` — visual futurista
- `main.js` — interações, chat, voz e modo demo

## Como abrir

Você pode abrir `index.html` diretamente no navegador.

Para evitar limitações de navegador, use uma extensão como Live Server no VS Code.

## Backend esperado

O frontend já tenta se conectar a:

- `GET http://127.0.0.1:8000/health`
- `POST http://127.0.0.1:8000/chat`

### Exemplo de /health

```json
{
  "status": "ok",
  "openai": true,
  "claude": true
}
```

### Exemplo de /chat

Entrada:

```json
{
  "message": "Jarvis, abra o Spotify",
  "provider": "auto"
}
```

Resposta:

```json
{
  "response": "Abrindo Spotify.",
  "intent": "OPEN_APP",
  "tool": "APP_LAUNCHER",
  "risk": "LOW",
  "activity": "Spotify aberto"
}
```

Enquanto o backend não existe, a interface entra automaticamente em modo demonstração.
